package bankApp;

public enum Currency {
    USED, EUR, KGS
}
